$(document).ready(function(){
  $('.searchable-select').select2();
})
