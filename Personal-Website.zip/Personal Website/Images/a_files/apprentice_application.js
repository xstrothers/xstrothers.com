function clRadioChange(radio){
  var inputs = $("#clQuestions input")
  console.log(inputs)
  if(radio.value == "Yes"){
    $("#clQuestions").show()
    inputs.each(input => inputs[input].setAttribute('required', true) );
  }else{
    $("#clQuestions").hide()
    inputs.each(input => inputs[input].removeAttribute('required') );
  }

}

function optOutChange(checkbox){
  var inputs = $("#textVideoQuestions textarea")
  if(checkbox.checked){
    $("#videoQuestions").hide()
    $("#textVideoQuestions").show()
    inputs.each(function(input){
      console.log(inputs[input])
      console.log(inputs)
      inputs[input].setAttribute('required', true)} );
      $("#whyTechHiddenInput")[0].setCustomValidity("")
      $("#whyTechHiddenInput").attr('value', '1')
      $("#whyTechHiddenInput")[0].reportValidity()
      $("#whyMAXXHiddenInput")[0].setCustomValidity("")
      $("#whyMAXXHiddenInput").attr('value', '1')
      $("#whyMAXXHiddenInput")[0].reportValidity()
      $("#noMAXXHiddenInput")[0].setCustomValidity("")
      $("#noMAXXHiddenInput").attr('value', '1')
      $("#noMAXXHiddenInput")[0].reportValidity()
  }else{
    $("#videoQuestions").show()
    $("#textVideoQuestions").hide()
    inputs.each(input => inputs[input].removeAttribute('required'));
  }
}

function relocateRadioChange(radio){
  var inputs = $("#relocationQuestions input")
  console.log(inputs)
  if(radio.value != "No"){
    $("#relocationQuestions").show()
    if(inputs.is(':checked')) {
        inputs.removeAttr('required');
    } else {
        inputs.attr('required', 'required');
    }
    inputs.each(input => inputs[input].setAttribute('required', true) );
  }else{
    $("#relocationQuestions").hide()
    inputs.each(input => inputs[input].removeAttribute('required') );
  }

}

function noticeRadioChange(radio){
  var input = $("#noticeAmtQuestion input")
  if(radio.value == "Yes"){
    console.log("yes")
    $("#noticeAmtQuestion").show()
    input.prop('required', true);
  }else{
    console.log("no")
    $("#noticeAmtQuestion").hide()
    input.prop('required', false);
    input.val(0);
  }

}



    var requiredCheckboxes = $("#relocationQuestions input")
    requiredCheckboxes.change(function(){
      console.log("checkbox")
        if(requiredCheckboxes.is(':checked')) {
            requiredCheckboxes.removeAttr('required');
        } else {
            requiredCheckboxes.attr('required', 'required');
        }
    });



const userAgent = navigator.userAgent;


let previewTech = document.getElementById("previewTech");
let previewMaxx = document.getElementById("previewMAXX");
let previewNo = document.getElementById("previewNo");


try{
  if (userAgent.indexOf('Firefox') > -1) {
    var recorderTech = new MediaRecorder(previewTech.mozCaptureStream());
    var recorderMaxx = new MediaRecorder(previewMaxx.mozCaptureStream());
    var recorderNo = new MediaRecorder(previewNo.mozCaptureStream());
  }else{
    var recorderTech = new MediaRecorder(previewTech.captureStream());
    var recorderMaxx = new MediaRecorder(previewMaxx.captureStream());
    var recorderNo = new MediaRecorder(previewNo.captureStream());

  }

}catch(err){
  console.log(err);
  var inputs = $("#textVideoQuestions textarea")
  $("#videoQuestions").hide()
  $("#textVideoQuestions").show()
  $("#optOutBlock").hide()
  $("#optOut").prop("checked", true);
  inputs.each(function(input){
    console.log(inputs[input])
    console.log(inputs)
    inputs[input].setAttribute('required', true)} );
}



let recordingTech = document.getElementById("recordingTech");
let recordedBlobTech = undefined;
let countTech = 3;
var intervalTech = undefined;
let dataTech = []
var techTimeout;
var techTimer;


if(typeof recorderTech !== 'undefined'){
recorderTech.ondataavailable = function(event){
  dataTech.push(event.data);
  recordedBlobTech = new Blob(dataTech, { type: "video/webm" });
  recordingTech.src = URL.createObjectURL(recordedBlobTech);
  console.log("video-finished")
  $("#whyTechHiddenInput")[0].setCustomValidity("")
  $("#whyTechHiddenInput").attr('value', '1')
  $("#whyTechHiddenInput")[0].reportValidity()
  log("Successfully recorded " + recordedBlobTech.size + " bytes of " +
      recordedBlobTech.type + " media.");
}

recordingTech.onloadedmetadata = function() {
    // it should already be available here
    console.log(' duration: ' + recordingTech.duration);
    // handle chrome's bug
    if (recordingTech.duration === Infinity) {
      // set it to bigger than the actual duration
      recordingTech.currentTime = 1e101;
      recordingTech.ontimeupdate = function() {
        this.ontimeupdate = () => {
          return;
        }
        console.log(' after workaround: ' + recordingTech.duration);
        recordingTech.currentTime = 0;
      }
    }
  }

}

let recordingMaxx = document.getElementById("recordingMAXX");
let recordedBlobMaxx = undefined;
let countMaxx = 3;
var intervalMaxx = undefined;
let dataMaxx = []
var maxxTimeout;
var maxxTimer;


if(typeof recorderMaxx !== "undefined"){
recorderMaxx.ondataavailable = function(event){
  dataMaxx.push(event.data);
  recordedBlobMaxx = new Blob(dataMaxx, { type: "video/webm" });
  recordingMaxx.src = URL.createObjectURL(recordedBlobMaxx);

  $("#whyMAXXHiddenInput")[0].setCustomValidity("")
  $("#whyMAXXHiddenInput").attr('value', '1')
  $("#whyMAXXHiddenInput")[0].reportValidity()

  log("Successfully recorded " + recordedBlobMaxx.size + " bytes of " +
      recordedBlobMaxx.type + " media.");
}

recordingMaxx.onloadedmetadata = function() {
    // it should already be available here
    console.log(' duration: ' + recordingMaxx.duration);
    // handle chrome's bug
    if (recordingMaxx.duration === Infinity) {
      // set it to bigger than the actual duration
      recordingMaxx.currentTime = 1e101;
      recordingMaxx.ontimeupdate = function() {
        this.ontimeupdate = () => {
          return;
        }
        console.log(' after workaround: ' + recordingMaxx.duration);
        recordingMaxx.currentTime = 0;
      }
    }
  }

}



let recordingNo = document.getElementById("recordingNo");
let recordedBlobNo = undefined;
let countNo = 3;
var intervalNo = undefined;
let dataNo = []
var noTimeout;
var noTimer;


if(recorderNo){
recorderNo.ondataavailable = function(event){
  dataNo.push(event.data);
  recordedBlobNo = new Blob(dataNo, { type: "video/webm" });
  recordingNo.src = URL.createObjectURL(recordedBlobNo);

  $("#noMAXXHiddenInput")[0].setCustomValidity("")
  $("#noMAXXHiddenInput").attr('value', '1')
  $("#noMAXXHiddenInput")[0].reportValidity()

  log("Successfully recorded " + recordedBlobNo.size + " bytes of " +
      recordedBlobNo.type + " media.");
}

recordingNo.onloadedmetadata = function() {
    // it should already be available here
    console.log(' duration: ' + recordingNo.duration);
    // handle chrome's bug
    if (recordingNo.duration === Infinity) {
      // set it to bigger than the actual duration
      recordingNo.currentTime = 1e101;
      recordingNo.ontimeupdate = function() {
        this.ontimeupdate = () => {
          return;
        }
        console.log(' after workaround: ' + recordingNo.duration);
        recordingNo.currentTime = 0;
      }
    }
  }

}


function log(msg) {
  console.log(msg + "\n");
}

function wait(delayInMS) {
  return new Promise(resolve => setTimeout(resolve, delayInMS));
}

function stop(stream,videoTag) {
  stream.getTracks().forEach(track => track.stop());
  document.getElementById("previewContainer" + videoTag).style.display = "none";
  document.getElementById("recordingContainer" + videoTag).style.display = "block";
}

function startTimer(videoTag) {
  var presentTime = document.getElementById('timer'+videoTag).innerHTML;
  var timeArray = presentTime.split(/[:]+/);
  var m = timeArray[0];
  var s = checkSecond((timeArray[1] - 1));
  if(s==59){m=m-1}
  //if(m<0){alert('timer completed')}

  document.getElementById('timer'+videoTag).innerHTML =
    m + ":" + s;
  // console.log(m)
  // setTimeout(startTimer, 1000);
}

function checkSecond(sec) {
  if (sec < 10 && sec >= 0) {sec = "0" + sec}; // add zero in front of numbers < 10
  if (sec < 0) {sec = "59"};
  return sec;
}





function techLimiter(maxTime){
  techTimeout = setTimeout(function(){
    if(recorderTech.state == "recording"){
      console.log("timeout hit");
      stopTech(previewTech.srcObject, "Tech")
    }
  }, maxTime);
}

function stopTech(stream,videoTag) {
  stream.getTracks().forEach(track => track.stop());
  document.getElementById("previewContainer" + videoTag).style.display = "none";
  document.getElementById("recordingContainer" + videoTag).style.display = "block";
  recorderTech.stop();
  clearInterval(techTimer);
}

function startRecordingTech(stream, lengthInMS) {
  recorderTech.start();
  techLimiter(lengthInMS);
  techTimer = setInterval(() => startTimer("Tech"), 1000);
}

function startCountdownTech(){
	if(countTech >= 1){
		document.getElementById("countdownTech").innerHTML = countTech;
		countTech--;
		console.log(countTech)
	}else{
		clearInterval(intervalTech)
		document.getElementById("preRecordTech").style.display = "none";
		document.getElementById("duringRecordTech").style.display = "block";
		startRecordingTech(previewTech.captureStream(), 1000 * 60 * 2)

	}
}
let readyTech = document.getElementById("readyTech");
readyTech.addEventListener("click", function(){
  try {

	navigator.mediaDevices.getUserMedia({
    video: true,
    audio: true
  }).then(stream => {
    previewTech.srcObject = stream;
    previewTech.captureStream = previewTech.captureStream || previewTech.mozCaptureStream;
    document.getElementById("startOverlayTech").style.display = "none";
    document.getElementById("previewContainerTech").style.display = "block";

    return new Promise(resolve => previewTech.onplaying = resolve);
  }).catch(error => alert('Unable to start media device, please check your current browser/camera settings, or proceed with the "Opt Out of Video Responses" option'))
  } catch (e) {
    alert('Unable to start media device, please check your current browser/camera settings, or proceed with the "Opt Out of Video Responses" option')
  }
});

document.getElementById("startButtonTech").addEventListener("click", function() {
  intervalTech = setInterval(function(){startCountdownTech()}, 1000)
});

document.getElementById("stopButtonTech").addEventListener("click", function() {
  stopTech(previewTech.srcObject, "Tech");
  clearTimeout(techTimeout);
}, false);

document.getElementById("clearButtonTech").addEventListener("click", function() {
  recordingTech.pause();
  recordingTech.removeAttribute('src'); // empty source
  recordingTech.load();
  dataTech = [];
  recordedBlobTech = undefined;
  countTech = 3;
  document.getElementById('timerTech').innerHTML =
    "2:00";
	document.getElementById("recordingContainerTech").style.display = "none";
	document.getElementById("startOverlayTech").style.display = "table";
  document.getElementById("preRecordTech").style.display = "block";
  document.getElementById("duringRecordTech").style.display = "none";
  document.getElementById("countdownTech").innerHTML = "";
})







function maxxLimiter(maxTime){
  maxxTimeout = setTimeout(function(){
    if(recorderMaxx.state == "recording"){
      console.log("timeout hit");
      stopMaxx(previewTech.srcObject, "MAXX")
    }
  }, maxTime);
}

function stopMaxx(stream,videoTag) {
  stream.getTracks().forEach(track => track.stop());
  document.getElementById("previewContainer" + videoTag).style.display = "none";
  document.getElementById("recordingContainer" + videoTag).style.display = "block";
  recorderMaxx.stop();
  clearInterval(maxxTimer);
}

function startRecordingMaxx(stream, lengthInMS) {
  recorderMaxx.start();
  maxxLimiter(lengthInMS);
  maxxTimer = setInterval(() => startTimer("MAXX"), 1000);
}

function startCountdownMaxx(){
	if(countMaxx >= 1){
		document.getElementById("countdownMAXX").innerHTML = countMaxx;
		countMaxx--;
		console.log(countMaxx)
	}else{
		clearInterval(intervalMaxx)
		document.getElementById("preRecordMAXX").style.display = "none";
		document.getElementById("duringRecordMAXX").style.display = "block";
		startRecordingMaxx(previewMaxx.captureStream(), 1000 * 60 * 2)

	}
}
let readyMaxx = document.getElementById("readyMAXX");
readyMaxx.addEventListener("click", function(){
  try{
  	navigator.mediaDevices.getUserMedia({
      video: true,
      audio: true
    }).then(stream => {
      previewMaxx.srcObject = stream;
      previewMaxx.captureStream = previewMaxx.captureStream || previewMaxx.mozCaptureStream;
      document.getElementById("startOverlayMAXX").style.display = "none";
      document.getElementById("previewContainerMAXX").style.display = "block";

      return new Promise(resolve => previewMaxx.onplaying = resolve);
    }).catch(error => alert('Unable to start media device, please check your current browser/camera settings, or proceed with the "Opt Out of Video Responses" option'))
  } catch (e) {
    alert('Unable to start media device, please check your current browser/camera settings, or proceed with the "Opt Out of Video Responses" option')
  }
});

document.getElementById("startButtonMAXX").addEventListener("click", function() {
  intervalMaxx = setInterval(function(){startCountdownMaxx()}, 1000)
});

document.getElementById("stopButtonMAXX").addEventListener("click", function() {
  stopMaxx(previewMaxx.srcObject, "MAXX");
  clearTimeout(maxxTimeout);
}, false);

document.getElementById("clearButtonMAXX").addEventListener("click", function() {
  recordingMaxx.pause();
  recordingMaxx.removeAttribute('src'); // empty source
  recordingMaxx.load();
  dataMaxx = [];
  recordedBlobMaxx = undefined;
  countMaxx = 3;
  document.getElementById('timerMAXX').innerHTML =
    "2:00";
	document.getElementById("recordingContainerMAXX").style.display = "none";
	document.getElementById("startOverlayMAXX").style.display = "table";
  document.getElementById("preRecordMAXX").style.display = "block";
  document.getElementById("duringRecordMAXX").style.display = "none";
  document.getElementById("countdownMAXX").innerHTML = "";
})






function noLimiter(maxTime){
  noTimeout = setTimeout(function(){
    if(recorderNo.state == "recording"){
      console.log("timeout hit");
      stopNo(previewNo.srcObject, "No")
    }
  }, maxTime);
}

function stopNo(stream,videoTag) {
  stream.getTracks().forEach(track => track.stop());
  document.getElementById("previewContainer" + videoTag).style.display = "none";
  document.getElementById("recordingContainer" + videoTag).style.display = "block";
  recorderNo.stop();
  clearInterval(noTimer);
}

function startRecordingNo(stream, lengthInMS) {
  recorderNo.start();
  noLimiter(lengthInMS);
  noTimer = setInterval(() => startTimer("No"), 1000);
}

function startCountdownNo(){
	if(countNo >= 1){
		document.getElementById("countdownNo").innerHTML = countNo;
		countNo--;
		console.log(countNo)
	}else{
		clearInterval(intervalNo)
		document.getElementById("preRecordNo").style.display = "none";
		document.getElementById("duringRecordNo").style.display = "block";
		startRecordingNo(previewNo.captureStream(), 1000 * 60 * 2)

	}
}
let readyNo = document.getElementById("readyNo");
readyNo.addEventListener("click", function(){
  try{
  	navigator.mediaDevices.getUserMedia({
      video: true,
      audio: true
    }).then(stream => {
      previewNo.srcObject = stream;
      previewNo.captureStream = previewNo.captureStream || previewNo.mozCaptureStream;
      document.getElementById("startOverlayNo").style.display = "none";
      document.getElementById("previewContainerNo").style.display = "block";

      return new Promise(resolve => previewNo.onplaying = resolve);
    }).catch(error => alert('Unable to start media device, please check your current browser/camera settings, or proceed with the "Opt Out of Video Responses" option'))
  } catch (e) {
    alert('Unable to start media device, please check your current browser/camera settings, or proceed with the "Opt Out of Video Responses" option')
  }
});

document.getElementById("startButtonNo").addEventListener("click", function() {
  intervalNo = setInterval(function(){startCountdownNo()}, 1000)
});

document.getElementById("stopButtonNo").addEventListener("click", function() {
  stopNo(previewNo.srcObject, "No");
  clearTimeout(noTimeout);
}, false);

document.getElementById("clearButtonNo").addEventListener("click", function() {
  recordingNo.pause();
  recordingNo.removeAttribute('src'); // empty source
  recordingNo.load();
  dataNo = [];
  recordedBlobNo = undefined;
  countNo = 3;
  document.getElementById('timerNo').innerHTML = "2:00";
	document.getElementById("recordingContainerNo").style.display = "none";
	document.getElementById("startOverlayNo").style.display = "table";
  document.getElementById("preRecordNo").style.display = "block";
  document.getElementById("duringRecordNo").style.display = "none";
  document.getElementById("countdownNo").innerHTML = "";
})




$('#appForm').on('submit', function (e) {
    console.log("submission")
    e.preventDefault();
    var form_data = new FormData($('#appForm')[0])
    if(recordedBlobTech && recordedBlobMaxx && recordedBlobNo && !($("#optOut").is(':checked'))){

      form_data.append('techVideo', recordedBlobTech, "techVideo.webm");
      form_data.append('maxxVideo', recordedBlobMaxx, "maxxVideo.webm");
      form_data.append('noVideo', recordedBlobNo, "noVideo.webm");

    }
    console.log($("#optOut").is(':checked'))
    if((recordedBlobTech && recordedBlobMaxx && recordedBlobNo) || $("#optOut").is(':checked')){
      $("#applicationUploadModal").modal({
         escapeClose: false,
         clickClose: false,
         showClose: false
        });
      $.ajax({
        url:"/apprentice-applications",
        data: form_data,
        method: "POST",
        processData: false,
        contentType: false
      }).done(function(data) {
          $("#applicationUploadModal").modal('toggle')
           console.log(data);
           if("redirect" in data){
             window.location.href = data['redirect']
           }
      }).fail(function(jqXHR){
        $("#applicationUploadModal").modal('toggle')
        alert('Something went wrong with your application, please reach out to gonzo@maxxpotential.com')
      });
    }else{
      console.log("invalid")
      if(!recordedBlobTech){
        $("#whyTechHiddenInput")[0].setCustomValidity("Missing Video")
        $("#whyTechHiddenInput")[0].reportValidity()
      }
      if(!recordedBlobMaxx){
        $("#whyMAXXHiddenInput")[0].setCustomValidity("Missing Video")
        $("#whyMAXXHiddenInput")[0].reportValidity()
      }
      if(!recordedBlobNo){
        $("#noMAXXHiddenInput")[0].setCustomValidity("Missing Video")
        $("#noMAXXHiddenInput")[0].reportValidity()
      }
    }
    return false;


});
